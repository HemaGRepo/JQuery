(function(){
    $.fn.highlight=function(fgcol,bgcol){
        return this.each(function(){
            $(this).css({
                'font-weight':'bold',
                'color':fgcol,
                'background-color':bgcol,
                'border':'2px solid purple'
            });
        });
    }
})(jQuery)