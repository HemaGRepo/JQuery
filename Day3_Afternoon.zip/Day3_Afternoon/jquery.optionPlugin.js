(function(){
    $.fn.optionPlugin=function(options){
        //Default values
        var defaultOps={
            fgColor:'white',
            bgColor:'red'
        };

        //If the user passes options use it, or use the default values
        var props=$.extend(defaultOps,options);

        return this.each(function(){
            $(this).css({
                'font-weight':'bold',
                'color':props.fgColor,
                'background-color':props.bgColor,
                'border':'2px solid purple'
            });
        });
    }
})(jQuery)