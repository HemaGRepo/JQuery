(function($){
	$.displayAlert=function(message){
		alert("Welcome "+message)
	};
})(jQuery);

//$- JQuery
//$.fn - JQuery functions
